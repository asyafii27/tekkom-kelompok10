<main id="main" class="mt-5">
    <!-- ======= About Section ======= -->
    <section id="skillss" class="skillss">
        <div class="container" data-aos="fade-up">
            <div class="section-title">
                <h2>About</h2>
                <p>Saya adalah Mahasiswa di Universitas Negeri Semarang.
                    Saya sekarang sedang menempuh jenjang strata-1 (S-1) pada program studi Teknik Informatika,
                    Jurusan Ilmu Komputer. fakultas Matematika dan Ilmu Pengetahuan Alam. Saya sekarang juga sedang
                    menjalani
                    Program Magang Studi Independen Bersertifikat di PT. Nurul Fikri Cipta Inovasi sebagai pada posisi
                    Fullstack Web Development</p>
            </div>

            <div class="row">
                <div class="col-lg-4">
                    <img src="assets/img/about.jpg" class="img-fluid" alt="">
                </div>
                <div class="col-lg-8 pt-4 pt-lg-0 content">
                    <h3>Informatics &amp; Engeineering</h3>
                    <p class="fst-italic">
                        Berikut ini adalah data diri saya:
                    </p>
                    <div class="row">
                        <div class="col-lg-6">
                            <ul>
                                <li><i class="bi bi-rounded-right"></i> <strong>Birthday:</strong> 27 May 2001</li>
                                <li><i class="bi bi-rounded-right"></i> <strong>Website:</strong> www.belumbuat.com</li>
                                <li><i class="bi bi-rounded-right"></i> <strong>Phone:</strong> 082223587065</li>
                                <li><i class="bi bi-rounded-right"></i> <strong>City:</strong> City : Pati, Central Java
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-6">
                            <ul>
                                <li><i class="bi bi-rounded-right"></i> <strong>Age:</strong> 21</li>
                                <li><i class="bi bi-rounded-right"></i> <strong>Degree:</strong> Beginner</li>
                                <li><i class="bi bi-rounded-right"></i> <strong>PhEmailone:</strong>
                                    ahmadsyafii2751@gmail.com
                                </li>
                            </ul>
                        </div>
                    </div>
                    <p>
                        Saya sebelumnya bersekolah di SMA Negeri 2 Pati. Sekolah yang menurut saya sangat disiplin
                        sekali dalam hal waktu. Ketika saya masih di SMA, saya mengikuti organisasi ROHIS (Kerohanian
                        Islam). Di dalam organisasi tersebut, saya tidak hanya belajar tentang agama islam itu sendiri.
                        Selain itu, saya juga mengikuti kegiatan ekstrakurikuler karya ilmiah. Dalam kegiatan tersebut
                        saya mendapatkan banyak sekali teman yang hebat-hebat.
                    </p>
                </div>
            </div>

        </div>
    </section><!-- End About Section -->
</main><!-- End #main -->